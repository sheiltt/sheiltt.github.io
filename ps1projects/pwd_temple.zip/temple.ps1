$host.UI.RawUI.WindowTitle = "PowerShellDownloader by sheilt | version 1.0"
$host.UI.RawUI.BackgroundColor = "Black"
$host.UI.RawUI.ForegroundColor = "White"
Clear-Host

Write-Host "PowerShellDownloader by sheilt" -ForegroundColor White
Write-Host "version 1.0" -ForegroundColor White
Write-Host " " -ForegroundColor Black

$url = "https://example.com/filename.exe" #write a link to the file here
$output = "C:\Downloads\file.exe" # (it doesn't have to be touched) this changes the path where the file will be saved. it also changes its name
$tempFile = "$env:TEMP\makutweaker_dl_progress.tmp"

function Show-Spinner {
    param(
        [int]$Percent,
        [string]$Status
    )
    $spinner = @('|', '/', '-', '\')
    $current = $script:spinnerPos % $spinner.Count
    Write-Host "`r[$($spinner[$current])] $Status ($Percent%) " -NoNewline -ForegroundColor Cyan
    $script:spinnerPos++
}

$script:spinnerPos = 0
$global:downloadComplete = $false

Write-Host "-------------------------------------------------------¬" -ForegroundColor DarkCyan
Write-Host "¦  	      INSTALLER TEST                          ¦" -ForegroundColor Cyan
Write-Host "+------------------------------------------------------+" -ForegroundColor DarkCyan
Write-Host "¦ The file will be saved in:                           ¦" -ForegroundColor White
Write-Host "¦ $output" -ForegroundColor Yellow
Write-Host "+------------------------------------------------------+" -ForegroundColor DarkCyan
Write-Host "¦ connecting to the server...                          ¦" -ForegroundColor White
Write-Host "L-------------------------------------------------------" -ForegroundColor DarkCyan

$downloadDir = Split-Path -Path $output -Parent
if (-not (Test-Path -Path $downloadDir)) {
    New-Item -ItemType Directory -Path $downloadDir | Out-Null
}

try {
    Write-Host "Getting information about a file..." -NoNewline
    $request = [System.Net.HttpWebRequest]::Create($url)
    $request.Method = "HEAD"
    $response = $request.GetResponse()
    $totalBytes = $response.ContentLength
    $fileSize = "{0:N2} MB" -f ($totalBytes/1MB)
    $response.Close()
    Write-Host "`rGetting information about a file... [?] ($fileSize)" -ForegroundColor Green

    Write-Host "`nThe beginning of the download..."
    $job = Start-Job -ScriptBlock {
        param($url, $output, $tempFile)
        
        try {
            $request = [System.Net.HttpWebRequest]::Create($url)
            $response = $request.GetResponse()
            $stream = $response.GetResponseStream()
            $fileStream = [System.IO.File]::Create($output)
            $buffer = New-Object byte[] 256KB
            $totalBytes = $response.ContentLength
            $downloadedBytes = 0
            
            while ($true) {
                $read = $stream.Read($buffer, 0, $buffer.Length)
                if ($read -le 0) { break }
                
                $fileStream.Write($buffer, 0, $read)
                $downloadedBytes += $read
                $percent = [math]::Round(($downloadedBytes / $totalBytes) * 100)
                "$percent,$downloadedBytes,$totalBytes" | Out-File $tempFile -Force
            }
            
            $fileStream.Close()
            $stream.Close()
            $response.Close()
            "100,$downloadedBytes,$totalBytes" | Out-File $tempFile -Force
        }
        catch {
            "ERROR,$_" | Out-File $tempFile -Force
        }
    } -ArgumentList $url, $output, $tempFile

    while ($job.State -eq 'Running') {
        if (Test-Path $tempFile) {
            $data = Get-Content $tempFile -Raw
            if ($data -like "ERROR,*") {
                throw ($data -replace "ERROR,","")
            }
            
            $parts = $data -split ','
            $percent = $parts[0]
            $downloaded = [double]$parts[1]
            $total = [double]$parts[2]
            
            $speed = ($downloaded / (Get-Date).Second) / 1MB * 8
            $status = "{0:N1} MB from {1:N1} MB | {2:N2} Mbit/s" -f ($downloaded/1MB), ($total/1MB), $speed
            
            Show-Spinner -Percent $percent -Status $status
        }
        Start-Sleep -Milliseconds 200
    }

    Remove-Item $tempFile -ErrorAction SilentlyContinue
    Write-Host "`r[?] The download is complete!                          " -ForegroundColor Green
    
    Write-Host "-------------------------------------------------------¬" -ForegroundColor DarkGreen
    Write-Host "¦ FILE HAS BEEN UPLOADED SUCCESSFULLY!                 ¦" -ForegroundColor Green
    Write-Host "+------------------------------------------------------+" -ForegroundColor DarkGreen
    Write-Host "¦ File path: $output" -ForegroundColor Yellow
    Write-Host "L-------------------------------------------------------" -ForegroundColor DarkGreen
}
catch {
    Write-Host "what the fuck :/                                        " -ForegroundColor Red
    Write-Host "                                                        " -ForegroundColor White
    Write-Host "-------------------------------------------------------¬" -ForegroundColor DarkRed
    Write-Host "¦ ERROR!!!!!!!!!!!!                                    ¦" -ForegroundColor Red
    Write-Host "+------------------------------------------------------+" -ForegroundColor DarkRed
    Write-Host "¦ Reason $_" -ForegroundColor White
    Write-Host "L-------------------------------------------------------" -ForegroundColor DarkRed
}
finally {
    if (Test-Path $tempFile) { Remove-Item $tempFile -Force }
    if ($job -ne $null) { Remove-Job $job -Force }
    Write-Host "Press any key to exit..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}